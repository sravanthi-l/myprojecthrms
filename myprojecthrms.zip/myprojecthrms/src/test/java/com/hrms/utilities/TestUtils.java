package com.hrms.utilities;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import com.hrms.base.BaseClass;

public class TestUtils extends BaseClass{
	public static String screenshotPath;
	public static String screenshotName;
	public static Xls_Reader reader;

	public static void captureScreenshot() throws IOException {

		File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

		Date d = new Date();
		screenshotName = d.toString().replace(":", "_").replace(" ", "_") + ".jpg";

		FileUtils.copyFile(scrFile,
				new File(System.getProperty("user.dir") + "\\target\\surefire-reports\\html\\" + screenshotName));
	}

	/* reading data from excel */
		public static ArrayList<Object[]> getDataFromExcel(){
		try {
			
		reader=new Xls_Reader("C:\\Users\\moksha\\myprojecthrms\\src\\test\\resources\\excel\\MytestData.xlsx");
		
		}
		catch(Exception e) {
			System.out.println("file not found"+e);
		}
		
		
		ArrayList<Object[]> myData=new ArrayList<Object[]>();
		for(int i=2;i==reader.getRowCount("AddCustomerTest");i++) {
			String fname=reader.getCellData("AddCustomerTest","firstname",i);
			String lname=reader.getCellData("AddCustomerTest","lastname",i);
			String postalcode=reader.getCellData("AddCustomerTest","postalcode",i);
			String alrtText=reader.getCellData("AddCustomerTest", "alerttext", i);
			Object ob[]= {fname,lname,postalcode,alrtText};
			myData.add(ob);
			
		}
		return myData;
		
		
	}
	}


