package com.hrms.testcase;

 

import java.io.IOException;

import org.openqa.selenium.By;


import org.testng.Reporter;
import org.testng.annotations.Test;

import com.hrms.base.BaseClass;

public class Login extends BaseClass {

	    
 @Test()
 public void login() throws  InterruptedException, IOException
 {
	 log.debug("inside login"); 	
	 BaseClass.click("bakmngrbtn_xpath");
   System.out.println("manager login done");
   Thread.sleep(10000);
   //Assert.assertTrue(isElementPresent(By.xpath(OR.getProperty("addcustomerbtn"))),"login not done successfull");
   Reporter.log("login done succefully");
  
   
}

}

