package com.hrms.testcase;

import java.util.ArrayList;
import java.util.Iterator;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.hrms.utilities.TestUtils;

public class RougClass {
	public static WebDriver driver1;
	@BeforeMethod
	public void setUp() {
		System.setProperty("driver.chrome.driver", "D:\\JarFiles\\Drivers\\chromedriver_win32\\chromedriver.exe");
		driver1=new ChromeDriver();
		driver1.get("http://www.way2automation.com/angularjs-protractor/banking/#/login");
		driver1.findElement(By.xpath("//button[@ng-click='manager()']")).click();
		driver1.findElement(By.xpath("//button[@ng-click='addCust()']")).click();
		
	}
	
	@DataProvider()
	public Iterator<Object[]> getTestdata()
	{
		ArrayList<Object[]> testData =TestUtils.getDataFromExcel();
		return testData.iterator();
	}
	
   @Test(dataProvider="getTestdata")
	public static void addcustomerdetails(String fname,String lname,String postcode,String alerttext) {
	   driver1.findElement(By.xpath("//input[@ng-model='fName']")).clear();
		driver1.findElement(By.xpath("//input[@ng-model='fName']")).sendKeys(fname);
		driver1.findElement(By.xpath("//input[@ng-model='lName']")).clear();
		driver1.findElement(By.xpath("//input[@ng-model='lName']")).sendKeys(lname);
		
		driver1.findElement(By.xpath("//input[@ng-model='postCd']")).clear();
		driver1.findElement(By.xpath("//input[@ng-model='postCd']")).sendKeys(postcode);
		
   driver1.findElement(By.xpath("//button[@type='submit']")).click();
   }
}
