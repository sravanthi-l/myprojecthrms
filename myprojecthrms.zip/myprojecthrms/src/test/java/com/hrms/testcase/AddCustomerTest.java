package com.hrms.testcase;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.gargoylesoftware.htmlunit.javascript.background.JavaScriptExecutor;
import com.hrms.base.BaseClass;

public class AddCustomerTest extends BaseClass {
	
	
	
	@Test
	@Parameters({"firstnm","lname","postcode"})
	public void addcustomer(String firstnm,String lname,String postcode) throws InterruptedException {
		
		click("addcustomerbtn_xpath");
	   
		//log.debug("addcustomerbutton clicked");
		typevalue("custfname_xpath",firstnm);
		
		typevalue("lastname_xpath",lname);
		typevalue("postcode_css",postcode);
		Thread.sleep(30000);
		click("addbtn_css");
			//Assert.fail("add customer failed");
		log.debug("customer added");
		}
	
	
	/*@Test(dataProvider="getData")
	public void addCustomer(String firstnm,String Lastnm,String Postalcode) throws InterruptedException {
		driver.findElement(By.xpath(OR.getProperty("addcustomerbtn"))).click();
		log.debug("addcustomerbutton clicked");
		driver.findElement(By.xpath(OR.getProperty("custfname"))).sendKeys(firstnm);
		driver.findElement(By.xpath(OR.getProperty("custlname"))).sendKeys(Lastnm);
		driver.findElement(By.xpath(OR.getProperty("custpostalcode"))).sendKeys(Postalcode);
	Thread.sleep(30000);
		driver.findElement(By.xpath(OR.getProperty("btnaddcust"))).click();
	log.debug("customer added");
	}
	@SuppressWarnings("null")
	@DataProvider
	public Object[][] getData(){
		Object[][] data=null;
		String sheetname="AddCustomerTest";
		int rows=excel.getRowCount();
		int cols=excel.getColCount();
		
		for(int i=rows-2;i<=rows;rows++)
		{
			for(int j=0;j<=cols;j++) {
				
				data[i-2][j] =excel.getCellData(sheetname,j,i);
				//return data;
			}
		}
		return data; 
		
	} */
	
	

}
