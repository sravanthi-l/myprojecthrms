package com.hrms.base;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.NoSuchElementException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;


import com.hrms.utilities.Xls_Reader;
import com.hrms.utilities.ExtentManager;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class BaseClass {
 public static WebDriver driver;
 public static Properties config=new Properties();
 public static Properties OR=new Properties();
 public static FileInputStream fs;
 public static FileInputStream fs1;
 public static Logger log=Logger.getLogger("devpinoyLogger");
 public static Xls_Reader excel=new Xls_Reader(
			System.getProperty("user.dir") + "\\src\\test\\resources\\excel\\Mytestdata.xlsx");
 
public ExtentReports rep=ExtentManager.getInstance();

public static ExtentTest test;
 @BeforeSuite
 public void setup()
 {
	 if(driver==null) {
		 try {
			 fs=new FileInputStream((System.getProperty("user.dir")) + "\\src\\test\\resources\\properties\\config.properties");
			 config.load(fs); 
			 
			 log.debug("config file loaded");
		 }
		 catch(IOException e) {
			 e.printStackTrace();
		 }
		 try {
			 fs1=new FileInputStream("C:\\Users\\moksha\\myprojecthrms\\src\\test\\resources\\properties\\OR.properties");
			 OR.load(fs1);
            log.debug("OR file loaded");
		 }
		 catch(IOException e) {
			 e.printStackTrace();
		 }
		 
		 if(config.getProperty("browser").equals("chrome")) {
			 System.setProperty("webdriver.chrome.driver", "C:\\Users\\moksha\\myprojecthrms\\src\\test\\resources\\ecxcutables\\chromedriver.exe");
					 driver=new ChromeDriver();
					 log.debug("chrome browser launched");
					 
			  }
		 else  if(config.getProperty("browser").equals("firefox")) {
			 System.setProperty("webdriver.gecko.driver", "C:\\Users\\moksha\\myprojecthrms\\src\\test\\resources\\ecxcutables\\geckodriver.exe");
		 driver=new FirefoxDriver();
		 log.debug("firefox browser launched");
		 }
		 else
		 {
			 log.debug("invalid browser");
		 }
		 //String url1=(config.getProperty("url"));
		 //System.out.println(url1);
		//driver.manage().timeouts().implicitlyWait(Integer.parseInt(config.getProperty("implictlywait")), TimeUnit.MICROSECONDS);
	 }
 
	    log.debug("application loading");
		 driver.get(config.getProperty("url"));
		 log.debug("navigated to"+ config.getProperty("url"));
		 driver.manage().window().maximize();
		 driver.manage().timeouts().implicitlyWait(Integer.parseInt(config.getProperty("implictlywait")), TimeUnit.MICROSECONDS);
         log.debug("application loaded");
         ArrayList<String> wind=new ArrayList<String>(driver.getWindowHandles());
         driver.switchTo().window(wind.get(1));
 
 }

 public static void click(String locator) {

		if (locator.endsWith("_css")) {
			driver.findElement(By.cssSelector(OR.getProperty(locator))).click();
		} else if (locator.endsWith("_xpath")) {
		//System.out.println("true");
			driver.findElement(By.xpath(OR.getProperty(locator))).click();
		} else if (locator.endsWith("_id")) {
			driver.findElement(By.id(OR.getProperty(locator))).click();
		}
		//test.log(LogStatus.INFO, "Clicking on : " + locator);
	}

 
 public void typevalue(String locator1,String value) {
	 //System.out.println(OR.getProperty(locator));
	 System.out.println("locator is" + locator1 + "value is" + OR.getProperty(locator1));
	 
	 //System.out.println(OR.getProperty("firstname_css"));
	 if(locator1.endsWith("_xpath")) {
	 driver.findElement(By.xpath(OR.getProperty(locator1))).sendKeys(value);
	 }
	 else if(locator1.endsWith("_css")) {
		 driver.findElement(By.cssSelector(OR.getProperty(locator1))).sendKeys(value);
		 }
	 else if(locator1.endsWith("_id"))
	 {
		 driver.findElement(By.id(OR.getProperty(locator1))).sendKeys(value); 
	 }
	 else {
		 System.out.println("no element with such suffix");
	 }
	 
	 
	 test.log(LogStatus.INFO, "typing value in the locator " + locator1 + "is" + value);
 }
		
/* public static void  jsclick() {
	JavaScriptExecutor js=JavaScriptExecutor(driver);

 } */
 
 public boolean isElementPresent(By by) {
	  try {
		  
		  driver.findElement(by);
		  return true;
		 
	 }
	  catch(NoSuchElementException e)
	  {
		  return false;
	  
		  
	  }
 }
 
 public void waitingforelement(String locator)
 {
	 WebDriverWait wait=new WebDriverWait(driver,15);
	 wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath(OR.getProperty(locator)))));
	 
 }
 	 
	 public void teardown() {
		 if(driver!=null) {
			 driver.quit();
			 
			 log.debug("driver closed");
		 }
		 
	 }
}
 
 


		
	


